var consNo, consName, consEmail, unitsConsumed;
function validateForm()
{
    var expr = new RegExp("^[A-Z][a-zA-Z\s]*"); // regular expresion for name format
    consNo = document.getElementById("consNo").value
    consName = document.getElementById("consName").value
    consEmail = document.getElementById("consEmail").value
    unitsConsumed =  parseInt(document.getElementById("unitsNo").value)
	if(!consName.match(expr))
	{
		alert("Consumer name should start with capital letter and contain only characters\n Like 'Atanu'")
	}
	else{
		alert("Electric Bill\nConsumer No : "+consNo+"\nConsumer Name : "+consName+"\nEmail Address : "+consEmail+"\nUnits Consumed : "+unitsConsumed+"\nTotal Electric Charge : Rs."+calculateBill(unitsConsumed))
	}
	
}
function calculateBill(units) //Calculates electric bill
{
	if(units<=100)
	{
		return units * 2.96;
	}
	else {
		return 100 * 2.96 + (units - 100) * 5.56;
	}
}